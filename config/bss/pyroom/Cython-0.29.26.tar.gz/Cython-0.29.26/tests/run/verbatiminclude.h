static long cube(long x)
{
    return x * x * x;
}

#define long broken_long
